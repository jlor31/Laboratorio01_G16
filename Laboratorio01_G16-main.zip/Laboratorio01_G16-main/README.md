# Laboratorio01_G16
Repositorio con archivo ipynb correspondiente al Lab01
